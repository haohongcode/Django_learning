# -*- coding: utf-8 -*-

from django.views.generic import TemplateView


class TestTemplateView(TemplateView):
    # 设置模板文件
    template_name = "index.html"

    #  重写父类TemplateView中的get_context_data()方法
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # 增加模板变量info
        context["info"] = "这里是昊虹君写的技术笔记-昊虹AI笔记"
        return context
