from django.shortcuts import render  # 默认导入的模块
from django.urls import reverse

# Create your views here.


def index(request):
    # 在视图函数中使用reverse方法进行反向解析
    print('views函数中使用reverse解析的结果：' + reverse('URL0'))

    # 在模板的HTML中进行反向解析
    return render(request, 'index.html')  # 将渲染结果输出到index.html模板中
